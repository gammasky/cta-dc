# CTA 1DC index files

This folder contains observation and HDU index files in this format:
http://gamma-astro-data-formats.readthedocs.io/en/latest/data_storage/index.html

They can be used to select and access the data in a simple and efficient way.
